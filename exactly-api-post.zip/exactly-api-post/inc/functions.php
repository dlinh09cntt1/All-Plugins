<?php
// Get Url
function extUrl(){
    return get_site_url(null, '/wp-json/wp/v2/posts');
}
function extApiUrl(){
    $ext_url = (!empty(get_option('url_api_post'))) ? get_option('url_api_post') : extUrl();
    $ext_embed = get_option('show_featured_image');
    if($ext_embed == 1){
        $ext_url = $ext_url.'?_embed';
    }
    return $ext_url;
}
function extConnectionApi(){
    global $wp_version;
    $args = array(
        'timeout'     => 5,
        'redirection' => 5,
        'httpversion' => '1.0',
        'user-agent'  => 'WordPress/' . $wp_version . '; ' . home_url(),
        'blocking'    => true,
        'headers'     => array(),
        'cookies'     => array(),
        'body'        => null,
        'compress'    => false,
        'decompress'  => true,
        'sslverify'   => true,
        'stream'      => false,
        'filename'    => null
    );
    $url = extApiUrl();
    $response = wp_remote_get($url, $args);
    if(is_wp_error($response)){
        return;
    }
    $data = json_decode( wp_remote_retrieve_body( $response ) );
    return $data;
}
function extShowContentAPI(){
    $arr = array();
    $arr = extConnectionApi();
    $ext_per_page = get_option('url_api_per_page');
    if(empty($arr)){
        return;
    }
    $i = 0;
    if(!empty($arr)){
        foreach($arr as $item){
            if($i < intval($ext_per_page)){
                // Format the date.
                $fordate = date('n/j/Y', strtotime($item->modified));
                // Show link title and post date
                $thumb_full_url = '';
                $thumb_url = '';
                if ( ! empty( $item->featured_media ) && isset( $item->_embedded ) ) {
                    $thumb_full_url = $item->_embedded->{'wp:featuredmedia'}[0]->source_url;
                    $thumb_url = $item->_embedded->{'wp:featuredmedia'}[0]->media_details->sizes->medium->source_url;
                }
                $all_posts .= '<div class="ext-item-post"><div class="blog_thumbnails"><a href="' .esc_url($item->link). '"><img src="' . esc_url($thumb_full_url) . '" alt=""></a></div>' . 
                            '<h3 class="blog_title"><a href="' .esc_url($item->link). '">' . esc_html($item->title->rendered) . '</a></h3>' . '<p class="time_post">' .esc_html($fordate). '</p>' . wp_kses_post($item->excerpt->rendered) .'</div>';
            }
            $i++;
        }
        return $all_posts;
    }
}
// Get API
