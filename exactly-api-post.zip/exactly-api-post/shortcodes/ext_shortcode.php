<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
if(!function_exists('func_ext_post_api')){
    function func_ext_post_api($atts){
        ob_start();?>
            <div class="exactly_all_post">
                <?php echo extShowContentAPI();?>
            </div>
        <?php 
        return ob_get_clean();
    }
}
add_shortcode('exactly_api_posts', 'func_ext_post_api');
