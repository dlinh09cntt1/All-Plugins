<?php
/**
 * Plugin Name: Exactly Post API
 * Description: Retrieve articles from another site through that site's API, Displaying the fetched content as a shortcode.
 * Author: Linh D. Tran
 * Version: 1.0.0
 * License: GPLv2 or later
 */

// Define url
define('EXTAPI_NAME', 'extapi');
define('EXTAPI_DIR', plugin_dir_path(__FILE__));
define('EXTAPI_URL', plugin_dir_url(__FILE__));
// Include setting page and widget
require_once EXTAPI_DIR . 'shortcodes/ext_shortcode.php';
require_once EXTAPI_DIR . 'inc/functions.php';
require_once EXTAPI_DIR . 'inc/wp_admin_setting.php';
// Create main class
if(!class_exists('Ext_Post_API')){
    class Ext_Post_API{
        function __construct(){
            add_action('init', array($this, 'func_ext_post_api'));
        }
        function func_ext_post_api(){
            add_action('wp_enqueue_scripts', array($this, 'api_post_frontend_scripts'));
        }
        function api_post_frontend_scripts(){
            wp_enqueue_style('ext-api-style', plugins_url('assets/css/main_style.css', __FILE__), array(), true);
        }
    }
}
// create new object and run class Ext_Sendmail
function func_ext_api_post_obj(){
    $ext_api_post = new Ext_Post_API();
}
// Add plugin loaded
add_action('plugins_loaded', 'func_ext_api_post_obj');
