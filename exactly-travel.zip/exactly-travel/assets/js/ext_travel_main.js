/**
 * Custom javascript
 */
;(function($){
    'use strict'
    var extTab =  function(){
        var choice_tab = $('.ext-travel-settings-wrap .nav-tab-wrapper');
		var content_tab = $('.ext-travel-settings-wrap .settings_panel');
		choice_tab.on('click','.nav-tab',function(e){
			e.preventDefault();
			var _this = $(this);
			choice_tab.find('.nav-tab').siblings(_this).removeClass('nav-tab-active');
			_this.addClass('nav-tab-active');
			var tab = _this.attr("href");
			content_tab.not(tab).css("display","none");
			$(tab).fadeIn();
		})
    }
	var initMetaTab = function(){
		var navTabs = $( '#authors-commentary-navigation').children( '.nav-tab-wrapper' );
        var tabIndex = null;
		navTabs.children().each(function() {
			$( this ).on( 'click', function( evt ) {
                evt.preventDefault();
                if ( ! $( this ).hasClass( 'nav-tab-active' ) ) {
                    $( '.nav-tab-active' ).removeClass( 'nav-tab-active' );
                    $( this ).addClass( 'nav-tab-active' );
                    tabIndex = $( this ).index();
                    $( '#authors-commentary-navigation' ).children( 'div:not( .inside.hidden )' ).addClass( 'hidden' );
                    $( '#authors-commentary-navigation' ).children( 'div:nth-child(' + ( tabIndex ) + ')' ).addClass( 'hidden' );
                    $( '#authors-commentary-navigation' ).children( 'div:nth-child( ' + ( tabIndex + 2 ) + ')' ).removeClass( 'hidden' );
                }
            });
		});
	}
	/*
	var createInputElement = function($){
		var $inputElement, iInputCount;
		iInputCount = $( '#authors-commentary-resources' ).children().length;
		iInputCount++;
		$inputElement = $( '<input />' ).attr( 'type', 'text' ).attr( 'name', 'authors-commentary-resource-' + iInputCount ).attr( 'id', 'authors-commentary-resource-' + iInputCount ).attr( 'value', '' );
		return $inputElement;
	}
	var initAddProperties = function(){
		var $inputElement;
        $( '#authors-commentary-add-resource' ).on( 'click', function( evt ) {
            evt.preventDefault();
            $( '#authors-commentary-resources' ).append ( createInputElement( $ ) );
		});
	}
	*/
	var initRepeatField = function(){
		// code
		$( '#exactly-travel-meta #add-row' ).on('click', function() {
			var row = $( '#exactly-travel-meta .empty-row.custom-repeter-text' ).clone(true);
			row.removeClass( 'empty-row custom-repeter-text' ).css('display','table-row');
			row.insertBefore( '#exactly-travel-meta #repeatable-fieldset-one tbody>tr:last' );
			return false;
		});
		$( '#exactly-travel-meta .remove-row' ).on('click', function() {
			$(this).parents('tr').remove();
			return false;
		});
	}
	function resetIndex(){
		$('#gallery-metabox-list li').each(function(i) {
		   $(this).find('input:hidden').attr('name', 'ext_travel_gallery_id[' + i + ']');
		});
	};
	function fnSortable() {
		$('#gallery-metabox-list').sortable({
		   opacity: 0.6,
		   stop: function() {
			  resetIndex();
		   }
		});
	};
	var initAddGalleryImage = function(){
		var file_frame;
		$('.ext_travel_images_list').on('click', 'a.gallery-add', function(e) {
			e.preventDefault();
			if (file_frame) file_frame.close();
				file_frame = wp.media.frames.file_frame = wp.media({
					title: $(this).data('uploader-title'),
					button: {
					text: $(this).data('uploader-button-text'),
				},
				multiple: true
			});
			file_frame.on('select', function(){
				var index = 1;
				var listIndex = $('#gallery-metabox-list li').index($('#gallery-metabox-list li:last')),
				selection = file_frame.state().get('selection');
				selection.map(function(attachment, i) {
					attachment = attachment.toJSON(),
					index = listIndex + (i + 1);
					$('#gallery-metabox-list').append('<li><input type="hidden" name="ext_travel_gallery_id[' + index + ']" value="' + attachment.id + '"><img class="image-preview" src="' + attachment.sizes.thumbnail.url + '"><a class="change-image button button-small" href="#" data-uploader-title="Change image" data-uploader-button-text="Change image">Đổi hình</a><br><small class="ext_rm_img"><a class="remove-image" href="#">X</a></small></li>');
				});
			});
			fnSortable();
			file_frame.open();
		});
	};
	var initChangeImageGallery = function(){
		var file_frame;
		$('.ext_travel_images_list').on('click', 'a.change-image', function(e) {
			e.preventDefault();
			var that = $(this);
			if (file_frame) file_frame.close();
			file_frame = wp.media.frames.file_frame = wp.media({
				 title: $(this).data('uploader-title'),
				 button: {
				 text: $(this).data('uploader-button-text'),
			},
			multiple: false
			});
			file_frame.on( 'select', function(attachment) {
				 attachment = file_frame.state().get('selection').first().toJSON();
				 that.parent().find('input:hidden').attr('value', attachment.id);
				 that.parent().find('img.image-preview').attr('src', attachment.sizes.thumbnail.url);
			  });
			file_frame.open();
		});
	};
	var initDeleteImageGallery = function(){
		$('.ext_travel_images_list').on('click', 'a.remove-image', function(e){
			e.preventDefault();
			$(this).parents('li').animate({ opacity: 0 }, 200, function() {
				$(this).remove();
				resetIndex();
			});
		});
	};
    // Dom Ready
    $(function(){
		extTab();
		initMetaTab();
		initRepeatField();
		initAddGalleryImage();
		initChangeImageGallery();
		initDeleteImageGallery();
    });
})(jQuery);