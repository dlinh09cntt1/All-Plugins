;(function($){
    'use strict'
    var initSeachArchive = function(){
        var _search = $('#ext_search_btn');
        if(_search.length === 0) return;
        _search.on('click', function(e){
            e.preventDefault();
            var _this = $(this);
            _this.closest('.archive-ext-travel').addClass('hide_pagination');
            var _start = _this.closest('.ext_form_wrap').find('#ext_time_start').val(),
                _end = _this.closest('.ext_form_wrap').find('#ext_time_end').val(),
                _maxprice = _this.closest('.ext_form_wrap').find('#ext_budget').val(),
                data = {
                    'action': 'ext_travel_result',
                    'attr': _this.closest('.archive-travel-search').data('attrs').posts,
                    'ext_title' : _this.closest('.ext_form_wrap').find('#travel_keyword').val(),
                    'ext_start_date' : _this.closest('.ext_form_wrap').find('#ext_time_start').val(),
                    'ext_end_date' : _this.closest('.ext_form_wrap').find('#ext_time_end').val(),
                    'ext_max_budget' : _this.closest('.ext_form_wrap').find('#ext_budget').val(),
                    'per_page' : _this.closest('.archive-ext-travel').find('.archive-travel-content').data('posts_per-page'),
                    'paged' : _this.closest('.archive-ext-travel').find('.archive-travel-content').data('page')
                };
            $.ajax({
                cache: false,
                timeout: 8000,
                url: exactly_array_ajaxp.admin_ajax,
                type: "POST",
                data: data,
                beforeSend: function(xhr){
                    _this.text('Loading....')
                },
                success: function(data){
                    if(data){
                        _this.closest('.archive-ext-travel').find('.list_travels').empty().append(data);
                    }else{

                    }
                },
                error: function(error){
                    console.log('Error', + error);
                },
                complete: function(xhr){

                }
            })
        })
    }
    var initLoadPagination = function(){
        var _nav = $('.exactly_pagination li');
        $('.archive-ext-travel').on('click', '.exactly_pagination li', function(e){
            e.preventDefault();
            var _this = $(this);
            _nav.removeClass('active');
            _this.addClass('active');
            var _shownav = _this.closest('.archive-ext-travel');
            if(_shownav.hasClass('hide_pagination')){
                _shownav.removeClass('hide_pagination');
            }
            var posts_per_page = _this.closest('.archive-ext-travel').find('.archive-travel-content').data('posts_per-page'),
                post_type = _this.closest('.archive-ext-travel').find('.archive-travel-content').data('post_type'),
                paged = _this.children('a').data('page');
            $.ajax({
                cache: false,
                timeout: 8000,
                url: exactly_array_ajaxp.admin_ajax,
                type: "POST",
                data: ({
                    action: 'Loadpost_travel_pagination',
                    posts_per_page: posts_per_page,
                    post_type: post_type,
                    paged: paged
                }),
                beforeSend: function(){

                },
                success: function(data, textStatus, jqXHR){
                    $('.archive-travel-content').html(data);
                },
                error: function(jqXHR, textStatus, errorThrown){
                    console.log( 'The following error occured: ' + textStatus, errorThrown );
                },
                complete: function(jqXHR, textStatus){
                    
                }
            })
        })
    }
    var initClickShowBooking = function(){
        var _show = $('.ext_bk');
        _show.on('click', function(e){
            e.preventDefault();
            var _this = $(this);
            _this.next('.ext_get_booking').fadeIn(300);
        });
    }
    var initCloseFormBooking = function(){
        $('body').on('click', function(e){
            e.preventDefault();
            $('.ext_get_booking').fadeOut(300);
        })
        $('.ext_post_booking, .ext_bk').on('click', function(e){
            e.stopPropagation();
        })
        $('.ext_close').on('click', function(e){
            e.preventDefault();
            var _this = $(this);
            _this.closest('.ext_get_booking').fadeOut(300);
        })
    }
    var initBooking = function(){
        var _mail = $('.ext_form_mail');
        _mail.on('click', '#ext_submit', function(e){
            e.preventDefault();
            var _this = $(this),
                ext_name = $('#ext_username').val(),
                ext_email = $('#ext_email').val(),
                ext_subject = $('#ext_subject').val(),
                ext_title_travel = _this.closest('li').find('.ext_bk').data('ext_title'),
                ext_link_travel = _this.closest('li').find('.ext_bk').data('ext_url'),
                ext_comment = $('#ext_comment').val();
            if(ext_name == '' || ext_email == ''){
                $('.error_messager').text('Please input user/email!');
                return;
            }
            $.ajax({
                cache: false,
                timeout: 8000,
                url: exactly_array_ajaxp.admin_ajax,
                type: 'POST',
                data: ({
                    action: 'ExactlySendMailUser',
                    ext_name: ext_name,
                    ext_email: ext_email,
                    ext_subject: ext_subject,
                    ext_title_travel: ext_title_travel,
                    ext_link_travel: ext_link_travel,
                    ext_comment: ext_comment
                }),
                beforeSend: function(xhr){
                   
                },
                success: function(data){
                    if(data == false){
                        $('.error_messager').text('Email has not been sent!');
                    }else{
                        $('.error_messager').text('Email sent successfully!');
                    }
                },
                error: function(error){
                    console.log('Error! ' + error);
                },
                complete: function(xhr){

                }
            })
        })
    }
    var initNextPrev = function(){
        var slideW = $('.ext-image-container').width();
        var current = 0;
        $('.ext_previous').on('click', function(e){
            if(current > 0 && current <= $('.ext-image-container .ext-slide').children().length - 1){
                current--;
            }
            e.preventDefault();
            $('.ext-image-container').animate({
                scrollLeft: slideW * current
            }, 600);
        });
        $('.ext_next').on('click', function(e){
            if(current < $('.ext-image-container .ext-slide').children().length - 1){
                current++;
            }
            e.preventDefault();
            $('.ext-image-container').animate({
                scrollLeft: slideW * current
            }, 600);
        });
    }
    var initCheckLike = function(){
        $('.archive-ext-travel').on('click', '.ext_travel_like', function(e){
            e.preventDefault();
            var _this = $(this);
            if(_this.closest('body').hasClass('logged-in')){
                $.ajax({
                    cache: false,
                    timeout: 8000,
                    url: exactly_array_ajaxp.admin_ajax,
                    type: 'POST',
                    data: ({
                        action: 'ExactlyLike',
                        ext_post_id: _this.closest('.ext_travel_thumbnails').data('ids'),
                        ext_post_link: _this.prev('a').attr('href'),
                        ext_post_img: _this.prev('a').children('img').attr('src'),
                        ext_post_title: _this.closest('article').find('.travel_title a').text()
                    }),
                    beforeSend: function(xhr){
                    
                    },
                    success: function(data){
                    _this.addClass('ext_liked').text('Liked');
                    },
                    error: function(error){
                        console.log('Error! ' + error);
                    },
                    complete: function(xhr){

                    }
                })
            }else{
                return;
            }
        })
    }
    var initGetUrlLogin = function(){
        $('.archive-ext-travel').on('click', '.ext_login', function(e){
            var _this = $(this);
            var _href = _this.attr('href');
            if(_href.length === 0 ) return;
            window.location.replace(_href);
        })
    }
    var initRemoveLike = function(){
        $('.archive-ext-travel').on('click', '.ext_liked', function(e){
            e.preventDefault();
            var _this = $(this);
            $.ajax({
                cache: false,
                timeout: 8000,
                url: exactly_array_ajaxp.admin_ajax,
                type: 'POST',
                data: ({
                    action: 'Exactly_Remove_Like',
                    ext_post_id: _this.data('id_like')
                }),
                beforeSend: function(xhr){
                   
                },
                success: function(data){
                   _this.removeClass('ext_liked').addClass('ext_travel_like').text('Like');
                },
                error: function(error){
                    console.log('Error! ' + error);
                },
                complete: function(xhr){

                }
            })
        })
    }
    $(function(){
        initSeachArchive();
        initLoadPagination();
        initClickShowBooking();
        initCloseFormBooking();
        initBooking();
        initNextPrev();
        initCheckLike();
        initGetUrlLogin();
        initRemoveLike();
    });
})(jQuery);