<?php
function ext_travel_custom_excerpt($limit, $more){
    $excerpt = explode(' ', get_the_excerpt(), $limit);
    if (count($excerpt) >= $limit) {
        array_pop($excerpt);
        $excerpt = implode(" ", $excerpt) . esc_attr( $more );
    } else {
        $excerpt = implode(" ", $excerpt);
    }
    $excerpt = preg_replace('`\[[^\]]*\]`', '', $excerpt);
    return $excerpt;
}
function ext_travel_show_cat($taxonomy){
    global $post;
    $category = get_the_terms( $post->ID, $taxonomy );     
    foreach ( $category as $cat){?>
        <span id="<?php echo $cat->slug;?>" class="travel_term-heading"><?php echo $cat->name; ?></span>
    <?php }
}
function ext_travel_taxonomy($taxonomy){
    global $post;
    $tax_terms = get_the_terms( $post->ID, $taxonomy );
    $arr_term = array();
    $i = 0;
    if($tax_terms){
        foreach( $tax_terms  as $tax_term ){
            $arr_term[$i] = $tax_term->term_id;
            $i++;
        }
    }
    return $arr_term;
}
// ajax search
add_action('wp_ajax_ext_travel_result', 'ext_travel_result_init');
add_action('wp_ajax_nopriv_ext_travel_result', 'ext_travel_result_init');
function ext_travel_result_init(){
    $args = json_decode( stripslashes( $_POST['attrs'] ), true );
    $ext_title = $_POST['ext_title'];
    $ext_start_date = $_POST['ext_start_date'];
    $ext_end_date = $_POST['ext_end_date'];
    $ext_max_budget = $_POST['ext_max_budget'];
    $per_page = intval($_POST['per_page']);
    $paged = intval($_POST['paged']);
    $ext_excerpt = get_option('ext_archive_expert_length') ? get_option('ext_archive_expert_length') : 30;
    $ext_more = get_option('ext_archive_expert_more');
    $ext_travel_layer = (get_option('ext_travel_archive_layer') == 'ext_travel_grid') ? 'ext_travel_grid' : 'ext_travel_list';
    $read_more = get_option('ext_travel_archive_readmore');
    $ext_loadmore = get_option('ext_travel_archive_loadmore');
    $args_post = array(
        'post_type' => 'exactly_travel',
        'posts_per_page' => -1,
        's' => $ext_title,
        'post_status' => 'publish',
        'meta_query' => array(
            'relation' => 'OR',
            array(
                array(
                    'key' => 'ext-start-time',
                    'value' => $ext_start_date,
                    'type'      =>  'date',
                    'compare' => '>='
                ),
                array(
                    'key' => 'ext-end-time',
                    'value' => $ext_end_date,
                    'type'      =>  'date',
                    'compare' => '<='
                )
            ),
            array(
                'key' => 'ext-travel-main-price',
                'value' => $ext_max_budget,
                'type' => 'NUMERIC',
                'compare' => '>='
            )
        )
    );
    $wp_query = new WP_Query($args_post);
    $total_show =  $wp_query->post_count;
    if ( $wp_query->have_posts() ){
        while ( $wp_query->have_posts() ) : $wp_query->the_post();?>
        <article id="post-<?php the_ID(); ?>" <?php post_class( 'ext-travel-post' ); ?>>
            <div class="ext_travel_thumbnails" data-total="<?php echo esc_attr($i);?>">
                <?php if ( has_post_thumbnail() ) : ?>
                <div class="ext-travel-thumbnails">
                    <a href="<?php esc_url( the_permalink() ); ?>" aria-hidden="true">
                        <?php the_post_thumbnail('travel-blog', array( 'alt' => get_the_title() ) ); ?>
                    </a>
                    <a href="#" class="ext_travel_like">Like</a>
                </div>
                <?php endif;?>
                <div class="ext_travel_info">
                    <ul class="ext_list_taxonomy">
                        <li><span><?php echo esc_html__("Tour Type:");?></span><?php echo ext_travel_show_cat('exactly_travel_cat');?></li>
                        <li><span><?php echo esc_html__("Travel Activity:");?></span><?php echo ext_travel_show_cat('exactly_travel_activity');?></li>
                        <li><span><?php echo esc_html__("Travel Destination:");?></span><?php echo ext_travel_show_cat('exactly_travel_destination');?></li>
                        <li><span><?php echo esc_html__("Travel Duration:");?></span><?php echo ext_travel_show_cat('exactly_travel_duration');?></li>
                        <li><span><?php echo esc_html__("Travel Ranger Price:");?></span><?php echo ext_travel_show_cat('exactly_travel_price');?></li>
                    </ul>
                </div>
            </div>
            <div class="ext_travel_content">
                <h2 class="travel_title"><a href="<?php the_permalink();?>"><?php the_title();?></a></h2>
                <div class="ext_travel_excerpt"><?php echo ext_travel_custom_excerpt(intval($ext_excerpt),$ext_more);?></div>
                <?php if($read_more):?>
                    <div class="ext_travel_readmode"><a href="<?php the_permalink();?>"><?php echo esc_html__("read more");?></a></div>
                <?php endif;?>
            </div>
        </article>
        <?php endwhile;
    }else{
        echo 'Post not found!';
    }
    die();
}
function initCheckInArray($n){
    $id_loggin = array();
    $id_loggin = ExactlyLoadLike_init();
    $flag = false;
    foreach($id_loggin as $row => $innerArray){
        foreach($innerArray as $innerRow => $value){
            if($n == $value){
                $flag = true;
                break;
            }
        }
    }
    return $flag;
}
function initCheckUserID($user_id){
    $id_loggin = array();
    $id_loggin = ExactlyUserId_init();
    $flag = false;
    foreach($id_loggin as $row => $innerArray){
        foreach($innerArray as $innerRow => $value){
            if($user_id == $value){
                $flag = true;
                break;
            }
        }
    }
    return $flag;
}
// Pagination
function exactly_travel_paginate_function($item_per_page, $current_page, $total_records, $total_pages){
    $pagination = '';
    if($total_pages > 0 && $total_pages != 1 && $current_page <= $total_pages){
        $pagination .= '<ul class="exactly_pagination">';
        $right_links = $current_page + 3;
        $previous = $current_page - 1;
        $next = $current_page + 1;
        $first_link = true;
        // check current page > 1
        if($current_page > 1){
            $previous_link = ($previous == 0) ? 1 : $previous;
            $pagination .= '<li class="ext_first"><a href="#" data-page="1" title="First">&laquo;</a></li>'; // first link
            $pagination .= '<li><a href="#" data-page="'.$previous_link.'" title="Previous">&lt;</a></li>'; // previous link
            for($i = ($current_page - 2); $i < $current_page; $i++){
                if($i > 0){
                    $pagination .= '<li><a href="#" data-page="'.$i.'" title="Page'.$i.'">'.$i.'</a></li>';
                }
            }
            // set first link to false
            $first_link = false;
        }
        // check active page
        if($first_link){ // if current active page is first link
            $pagination .= '<li class="first active">'.$current_page.'</li>';
        }elseif($current_page == $total_pages){ // if it's the last active link
            $pagination .= '<li class="last active">'.$current_page.'</li>';
        }else{ // regular current link
            $pagination .= '<li class="active">'.$current_page.'</li>';
        }
        // create right-hand side links
        for($i = $current_page+1; $i < $right_links; $i++){
            if($i <= $total_pages){
                $pagination .= '<li><a href="#" data-page="'.$i.'" title="Page'.$i.'">'.$i.'</a></li>';
            }
        }
        if($current_page < $total_pages){
            $next_link = ($next > $total_pages) ? $total_pages : $next;
            $pagination .= '<li><a href="#" data-page="'.$next_link.'" title="Next">&gt;</a></li>'; // next link
            $pagination .= '<li class="last"><a href="#" data-page="'.$total_pages.'" title="Last">&raquo;</a></li>'; // last link
        }
        $pagination .= '</ul>';
    }
    return $pagination; // return pagination links
}
// function show post travel content
function exactly_travel_query_post($post_type, $posts_per_page, $paged){
    $ext_excerpt = get_option('ext_archive_expert_length') ? get_option('ext_archive_expert_length') : 30;
    $ext_more = get_option('ext_archive_expert_more');
    $ext_travel_layer = (get_option('ext_travel_archive_layer') == 'ext_travel_grid') ? 'ext_travel_grid' : 'ext_travel_list';
    $read_more = get_option('ext_travel_archive_readmore');
    $ext_pagination = get_option('ext_travel_archive_pagination');
    $args_post = array(
        'post_type' => $post_type,
        'posts_per_page' => $posts_per_page,
        'paged' => $paged,
        'post_status' => 'publish'
    );
    $wp_query = new WP_Query($args_post);
    $total_records = $wp_query->found_posts;
    $total_pages = ceil($total_records/$posts_per_page);
    $attrs = array(
        'posts' => json_encode($wp_query->query_vars),
        'posts_per_page' => $posts_per_page,
        'current_pages' => get_query_var( 'paged' ) ? get_query_var('paged') : 1,
        'max_pages' => $total_pages
    );?>
    <div class="list_travels <?php echo esc_attr($ext_travel_layer);?>">
    <?php if ( $wp_query->have_posts() ):
        while ( $wp_query->have_posts() ) : $wp_query->the_post();?>
        <article id="post-<?php the_ID(); ?>" <?php post_class( 'ext-travel-post' ); ?>>
            <div class="ext_travel_thumbnails" data-ids="<?php the_ID();?>">
                <?php if ( has_post_thumbnail() ) : ?>
                <div class="ext-travel-thumbnails">
                    <a href="<?php esc_url( the_permalink() ); ?>" aria-hidden="true">
                        <?php the_post_thumbnail('travel-blog', array( 'alt' => get_the_title() ) ); ?>
                    </a>
                    <?php 
                    if(initCheckInArray(intval(get_the_ID()))):?>
                        <a href="#" class="ext_liked" data-id_like="<?php echo get_the_ID();?>">Liked</a>
                    <?php else:?>
                        <a href="#" class="ext_travel_like">Like</a>
                    <?php endif;?>
                </div>
                <?php endif;?>
                <div class="ext_travel_info">
                    <ul class="ext_list_taxonomy">
                        <li><span><?php echo esc_html__("Tour Type:");?></span><?php echo ext_travel_show_cat('exactly_travel_cat');?></li>
                        <li><span><?php echo esc_html__("Travel Activity:");?></span><?php echo ext_travel_show_cat('exactly_travel_activity');?></li>
                        <li><span><?php echo esc_html__("Travel Destination:");?></span><?php echo ext_travel_show_cat('exactly_travel_destination');?></li>
                        <li><span><?php echo esc_html__("Travel Duration:");?></span><?php echo ext_travel_show_cat('exactly_travel_duration');?></li>
                        <li><span><?php echo esc_html__("Travel Ranger Price:");?></span><?php echo ext_travel_show_cat('exactly_travel_price');?></li>
                    </ul>
                </div>
            </div>
            <div class="ext_travel_content">
                <h2 class="travel_title"><a href="<?php the_permalink();?>"><?php the_title();?></a></h2>
                <div class="ext_travel_excerpt"><?php echo ext_travel_custom_excerpt(intval($ext_excerpt),$ext_more);?></div>
                <?php if($read_more):?>
                    <div class="ext_travel_readmode"><a href="<?php the_permalink();?>"><?php echo esc_html__("read more");?></a></div>
                <?php endif;?>
            </div>
        </article>
        <?php endwhile;
    endif;?>
    </div>
    <?php if($ext_pagination):?>
       <div class="ext_travel_pagination"><?php echo exactly_travel_paginate_function($posts_per_page, $paged, $total_records, $total_pages);?></div>
    <?php endif;
}
// Load travel post pagination
add_action('wp_ajax_Loadpost_travel_pagination', 'Loadpost_travel_pagination_init');
add_action('wp_ajax_nopriv_Loadpost_travel_pagination', 'Loadpost_travel_pagination_init');

function Loadpost_travel_pagination_init(){
    $posts_per_page = intval($_POST['posts_per_page']);
    $paged = intval($_POST['paged']);
    $post_type = sanitize_text_field($_POST['post_type']);
    exactly_travel_query_post($post_type, $posts_per_page, $paged);
    die();
}
// Booking email
add_action('wp_ajax_ExactlySendMailUser', 'ExactlySendMailUser_init');
add_action('wp_ajax_nopriv_ExactlySendMailUser', 'ExactlySendMailUser_init');
function ExactlySendMailUser_init(){
    $to = get_option('ext_main_email');
    // Get value after client send
    $ext_title_travel =  (!empty($_POST['ext_title_travel'])) ? $_POST['ext_title_travel'] : '';
    $ext_link_travel = (!empty($_POST['ext_link_travel'])) ? $_POST['ext_link_travel'] : '';
    $user_name = (!empty($_POST['ext_name'])) ? $_POST['ext_name'] : '';
    $user_email = (!empty($_POST['ext_email'])) ? $_POST['ext_email'] : '';
    $ext_subject = (!empty($_POST['ext_subject'])) ? $_POST['ext_subject'] : '';
    $ext_comment = (!empty($_POST['ext_comment'])) ? $_POST['ext_comment'] : '';
    $content = 'Username: '.$user_name.' Usermail: '.$user_email.' Comment: '.$ext_comment.' Title: '.$ext_title_travel.' Link: '.$ext_link_travel;
    $mailResult = false;
    $mailResult = wp_mail( $to, $ext_subject, $content);
    echo esc_attr($mailResult);
    die();
}
// New table save like post
global $jal_db_version;
$jal_db_version = '1.0';
function jal_install() {
	global $wpdb;
	global $jal_db_version;
	$table_name = $wpdb->prefix . 'like_posts';
	$charset_collate = $wpdb->get_charset_collate();
	$sql = "CREATE TABLE $table_name (
        stt mediumint(9) NOT NULL AUTO_INCREMENT,
		id mediumint(9) NOT NULL,
		member_id mediumint(9) NOT NULL,
		title tinytext NOT NULL,
        link varchar(500) DEFAULT '' NOT NULL,
		url varchar(550) DEFAULT '' NOT NULL,
		PRIMARY KEY  (stt)
	) $charset_collate;";
	require_once ABSPATH . 'wp-admin/includes/upgrade.php';
	dbDelta( $sql );
	add_option( 'jal_db_version', $jal_db_version );
}
// Get value load
function ExactlyLoadLike_init(){
    if (is_user_logged_in()) {
        global $wpdb;
        $user_ID = get_current_user_id(); 
        $table_name = $wpdb->prefix . 'like_posts';
        $sql = "SELECT id FROM $table_name WHERE member_id = %d";
        $data = $wpdb->get_results($wpdb->prepare($sql, $user_ID), ARRAY_A);
        return $data;
    }
}
// Get User Id
function ExactlyUserId_init(){
    if (is_user_logged_in()) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'like_posts';
        $sql = "SELECT DISTINCT member_id FROM $table_name";
        $data = $wpdb->get_results($wpdb->prepare($sql), ARRAY_A);
        return $data;
    }
}
// Check login like
add_action('wp_ajax_ExactlyLike', 'ExactlyLike_init');
add_action('wp_ajax_nopriv_ExactlyLike', 'ExactlyLike_init');
function ExactlyLike_init(){
    if (is_user_logged_in()) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'like_posts';
        $user_ID = get_current_user_id(); 
        $post_id = $_POST['ext_post_id'];
        $post_link = $_POST['ext_post_link'];
        $post_img = $_POST['ext_post_img'];
        $post_title = $_POST['ext_post_title'];
        if(!empty($post_id) || !empty($post_link) || !empty($post_img) || !empty($post_title) || isset($user_ID)){
            $wpdb->insert( 
                $table_name, 
                array( 
                    'id' => esc_html($post_id), 
                    'member_id' => esc_html($user_ID), 
                    'title' => esc_html($post_title), 
                    'link' => esc_url($post_link),
                    'url' => esc_url($post_img)
                ) 
            );
        }
        die();
    }else{?>
        <ul class="ext_login_register">
            <li><a href="<?php echo wp_login_url( get_permalink() ); ?>" class="ext_login">Click login!</a></li>
        </ul>
    <?php die();}
}
// Ajax remove like
add_action('wp_ajax_Exactly_Remove_Like', 'Exactly_Remove_Like_Init');
add_action('wp_ajax_nopriv_Exactly_Remove_Like', 'Exactly_Remove_Like_Init');
function Exactly_Remove_Like_Init(){
    if (is_user_logged_in()) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'like_posts';
        $user_ID = get_current_user_id(); 
        $post_id = $_POST['ext_post_id'];
        if(!empty($post_id)){
            $wpdb->delete( $table_name, array( 'id' => $post_id, 'member_id' => $user_ID ) );
        }
    }else{?>
        <ul class="ext_login_register">
            <li><a href="<?php echo wp_login_url( get_permalink() ); ?>" class="ext_login">Click login!</a></li>
        </ul>
    <?php }
    die();
}
/**
 * Register a new page under "Users".
 */
function wpdocs_my_users_menu() {
	add_users_page(
		__( 'Follow Travel', EXTTRAVEL_NAME ),
		__( 'Follow Travel', EXTTRAVEL_NAME ),
		'read',
		'exactly-manager-user',
		'exactly_manager_follow_user'
	);
}
add_action('admin_menu', 'wpdocs_my_users_menu');

function exactly_manager_follow_user(){
    include_once('user/exactly_travel_user.php');
}
