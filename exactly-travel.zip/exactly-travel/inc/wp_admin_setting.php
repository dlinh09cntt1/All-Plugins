<?php
if(!class_exists('ExtTravel_Admin_Setting')){
    class ExtTravel_Admin_Setting{
        public static $_instance = null;
		public static function instance(){
			if ( is_null( self::$_instance )) {
				self::$_instance = new self();
			}
			return self::$_instance;
		}
        public function __construct(){
            $this->settings_group = 'ext_travel_setting';
            // add section to setting
            add_action('admin_init', array($this, 'ext_travel_register_setting'));
            // add to menu dashboard
            add_action('admin_menu', array($this, 'ext_travel_menu_init'));
        }
        // init front end section
        public function ext_init_travel_frontend(){
            $this->settings = apply_filters('ext_travel_settings',
                array(
                    'ext_travel_general' => array(
                        __('General Travel', EXTTRAVEL_NAME),
                        array(
                            array(
                                'name'        => 'ext_main_email',
                                'label'      => __( 'Email booking', EXTTRAVEL_NAME ),
                                'desc'       => __( 'Input email of text field.', EXTTRAVEL_NAME),
                                'type'       => 'text',
                                'std'        => '',
                            ),
                            array(
								'name'    => 'ext_travel_show_start',
								'label'   => __('Show or Hide start', EXTTRAVEL_NAME),
								'desc'    => __('checked show or hide start of post'),
								'type'    => 'checkbox',
								'std'     => '1',
								'attributes' => array()
							),
                            array(
								'name'    => 'ext_travel_show_price',
								'label'   => __('Show or Hide price', EXTTRAVEL_NAME),
								'desc'    => __('checked show or hide price of post'),
								'type'    => 'checkbox',
								'std'     => '1',
								'attributes' => array()
							)
                        ),
                    ),
                    'ext_travel_archive' => array(
                        __('Travel post archive', EXTTRAVEL_NAME),
                        array(
                            array(
								'name'    => 'ext_travel_archive_search',
								'label'   => __('Show or Hide search form', EXTTRAVEL_NAME),
								'desc'    => __('checked show or hide search form of post'),
								'type'    => 'checkbox',
								'std'     => '1',
								'attributes' => array()
							),
                            array(
                                'name'        => 'ext_archive_per_page',
                                'label'      => __( 'Post per page', EXTTRAVEL_NAME ),
                                'desc'       => __( 'Input post per page of text field.', EXTTRAVEL_NAME),
                                'type'       => 'text',
                                'std'        => '',
                            ),
                            array(
                                'name'     => 'ext_travel_archive_layer',
                                'label'    => __('Select layer archive post', EXTTRAVEL_NAME),
                                'desc'     => __('Select layer archive post', EXTTRAVEL_NAME),
                                'type'     => 'select',
                                'std'      => 'ext_travel_grid',
                                'options'  => array(
                                    'ext_travel_grid' => 'Show post grid',
                                    'ext_travel_list'      => 'Show post list'
                                )
                            ),
                            array(
                                'name'     => 'ext_travel_order',
                                'label'    => __('Select order post', EXTTRAVEL_NAME),
                                'desc'     => __('Select order post', EXTTRAVEL_NAME),
                                'type'     => 'select',
                                'std'      => '',
                                'options'  => array(
                                    '' => 'none',
                                    'ext_travel_desc' => 'DESC',
                                    'ext_travel_asc'      => 'ASC'
                                )
                            ),
                            array(
                                'name'     => 'ext_travel_order_by',
                                'label'    => __('Select order by post', EXTTRAVEL_NAME),
                                'desc'     => __('Select order by post', EXTTRAVEL_NAME),
                                'type'     => 'select',
                                'std'      => '',
                                'options'  => array(
                                    '' => 'none',
                                    'ext_travel_order_title' => 'Title',
                                    'ext_travel_order_date'  => 'Date',
                                    'ext_travel_order_id'  => 'ID'
                                )
                            ),
                            array(
                                'name'        => 'ext_archive_expert_length',
                                'label'      => __( 'Expert', EXTTRAVEL_NAME ),
                                'desc'       => __( 'Input expert length of post.', EXTTRAVEL_NAME),
                                'type'       => 'text',
                                'std'        => '',
                            ),
                            array(
                                'name'        => 'ext_archive_expert_more',
                                'label'      => __( 'Expert', EXTTRAVEL_NAME ),
                                'desc'       => __( 'Input expert more of post.', EXTTRAVEL_NAME),
                                'type'       => 'text',
                                'std'        => '...',
                            ),
                            array(
								'name'    => 'ext_travel_archive_readmore',
								'label'   => __('Show or Hide read more', EXTTRAVEL_NAME),
								'desc'    => __('checked show or hide read more of post'),
								'type'    => 'checkbox',
								'std'     => '1',
								'attributes' => array()
							),
                            array(
								'name'    => 'ext_travel_archive_pagination',
								'label'   => __('Show or Hide Pagination', EXTTRAVEL_NAME),
								'desc'    => __('checked show or hide pagination of post'),
								'type'    => 'checkbox',
								'std'     => '1',
								'attributes' => array()
							)
                        ),
                    ),
                    'ext_travel_search_tours' => array(
                        __('Travel search tours', EXTTRAVEL_NAME),
                        array(
                            array(
                                'name'        => 'ext_travel_search_title',
                                'label'      => __( 'Title search', EXTTRAVEL_NAME ),
                                'desc'       => __( 'Input title search of text field.', EXTTRAVEL_NAME),
                                'type'       => 'text',
                                'std'        => '',
                            )
                        ),
                    ),
                )
            );
        }
        // register section to setting
        public function ext_travel_register_setting(){
            // callback init front end section to setting
            $this->ext_init_travel_frontend();
            foreach ( $this->settings as $section ) {
                foreach ( $section[1] as $option ) {
                    if ( isset( $option['std'] ) )
                        add_option( $option['name'], $option['std'] );
                    register_setting( $this->settings_group, $option['name'] );
                }
            }
        }
        // Show menu setting on dashboard
        public function ext_travel_menu_init(){
            add_submenu_page( 'edit.php?post_type=exactly_travel', esc_html__( 'Settings', EXTTRAVEL_NAME ), esc_html__( 'Settings', EXTTRAVEL_NAME ), 'manage_options', 'exactly-travel-settings', array( $this, 'ext_travel_settings_render' ));
        }
        // render admin setting plugin
        public function ext_travel_settings_render(){?>
            <div class="wrap ext-travel-settings-wrap">
            <form method="post" action="options.php">
                <?php settings_fields( $this->settings_group ); ?>
                <h2 class="nav-tab-wrapper">
                    <?php
					$i=0;
					foreach ( $this->settings as $key => $section ) {?>
						<a href="#settings-<?php echo sanitize_title( $key );?>" class="nav-tab <?php if($i==0) echo 'nav-tab-active';?>"><?php echo esc_html($section[0]);?></a>
					<?php $i++;}?>
                </h2>
					<?php
                    if ( ! empty( $_GET['settings-updated'] ) ) {
                        flush_rewrite_rules();
                        echo '<div class="updated job-manager-updated"><p>' . __( 'Settings successfully saved', EXTTRAVEL_NAME ) . '</p></div>';
                    }
                    foreach ( $this->settings as $key => $section ) {
                        echo '<div id="settings-' . sanitize_title( $key ) . '" class="settings_panel">';
                        echo '<table class="form-table">';
                        foreach ( $section[1] as $option ) {
                            $placeholder    = ( ! empty( $option['placeholder'] ) ) ? 'placeholder="' . $option['placeholder'] . '"' : '';
                            $class          = ! empty( $option['class'] ) ? $option['class'] : '';
                            $value          = get_option( $option['name'] );
                            $option['type'] = ! empty( $option['type'] ) ? $option['type'] : '';
                            $attributes     = array();
                            if ( ! empty( $option['attributes'] ) && is_array( $option['attributes'] ) )
                                foreach ( $option['attributes'] as $attribute_name => $attribute_value )
                                    $attributes[] = esc_attr( $attribute_name ) . '="' . esc_attr( $attribute_value ) . '"';
                            echo '<tr valign="top" class="' . $class . '"><th scope="row"><label for="setting-' . $option['name'] . '">' . $option['label'] . '</a></th><td>';
                            switch ( $option['type'] ) {
                                case "text" :
                                    ?><input id="setting-<?php echo $option['name']; ?>" class="<?php echo $option['name']; ?>a" type="text" name="<?php echo $option['name']; ?>" value="<?php echo esc_attr( $value ); ?>" <?php echo implode( ' ', $attributes ); ?> <?php echo $placeholder; ?> style="width:80%"/><?php
                                    if ( $option['desc'] ) {
                                        echo ' <p class="description">' . $option['desc'] . '</p>';
                                    }
                                break;
                                case "select" :
                                    ?><select id="setting-<?php echo $option['name']; ?>" class="<?php echo $option['name']; ?>a" name="<?php echo $option['name']; ?>" <?php echo implode( ' ', $attributes ); ?>><?php
                                        foreach( $option['options'] as $key => $name )
                                            echo '<option value="' . esc_attr( $key ) . '" ' . selected( $value, $key, false ) . '>' . esc_html( $name ) . '</option>';
                                    ?></select><?php
                                    if ( $option['desc'] ) {
                                        echo ' <p class="description">' . $option['desc'] . '</p>';
                                    }
                                break;
								case "checkbox" :
                                    ?><label><input id="setting-<?php echo $option['name']; ?>" name="<?php echo $option['name']; ?>" type="checkbox" value="1" <?php echo implode( ' ', $attributes ); ?> <?php checked( '1', $value ); ?> /></label><?php
                                    if ( $option['desc'] )
                                        echo ' <span class="description">' . $option['desc'] . '</span>';
                                break;
                                default :
                                    do_action( 'ext_travel_admin_field_' . $option['type'], $option, $attributes, $value, $placeholder );
                                break;
                            }
                            echo '</td></tr>';
                        }
                        echo '</table></div>';
                    }
                ?>
                <p class="submit">
                    <input type="submit" class="button-primary" value="<?php _e( 'Save Changes', EXTTRAVEL_NAME ); ?>" />
                </p>
            </form>
        </div>
		<?php 
        }
    }
}
ExtTravel_Admin_Setting::instance();