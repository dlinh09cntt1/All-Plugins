<div class="ext_form_mail">
    <form id="ext_mail" class="ext_mail" method="post" action="">
        <input type="text" id="ext_username" name="ext_username" placeholder="Full name" />
        <input type="email" id="ext_email" name="ext_email" placeholder="Email" />
        <input type="text" id="ext_subject" name="ext_subject" placeholder="Subject" />
        <textarea name="ext_comment" id="ext_comment" placeholder="Your ideas" rows="4" cols="50"></textarea><br />
        <input type="submit" name="ext_submit" id="ext_submit" value="Book by email" />
        <label><span class="error_messager"></span></label>
    </form>
</div>