<?php
class Ext_Travel_Booking_Form{
    public function __construct(){
        add_action('wp_ajax_ExactlySendMailUser', array($this, 'ExactlySendMailUser_init'));
        add_action('wp_ajax_nopriv_ExactlySendMailUser', array($this, 'ExactlySendMailUser_init'));
        add_action( 'widgets_init', array($this, 'ext_travel__widgets_init'), 99);
        add_shortcode( 'exactly_form_mail', array($this, 'func_ext_sendmail') );
    }
    public function ExactlySendMailUser_init(){
        $to = get_option('ext_main_email');
        // Get value after client send
        $user_name = (!empty($_POST['ext_name'])) ? $_POST['ext_name'] : '';
        $user_email = (!empty($_POST['ext_email'])) ? $_POST['ext_email'] : '';
        $ext_subject = (!empty($_POST['ext_subject'])) ? $_POST['ext_subject'] : '';
        $ext_comment = (!empty($_POST['ext_comment'])) ? $_POST['ext_comment'] : '';
        $content = 'Username: '.$user_name.' Usermail: '.$user_email.' Comment: '.$ext_comment;
        $mailResult = false;
        $mailResult = wp_mail( $to, $ext_subject, $content);
        echo esc_attr($mailResult);
        die();
    }
    public function ext_travel__widgets_init(){
        register_sidebar( array(
            'name'          => esc_html__( 'Exactly mail sidebar', EXTTRAVEL_NAME ),
            'id'            => 'ext-sendmail-sidebar',
            'description'   => esc_html__( 'Add widgets here to appear in your sidebar Ext', EXTTRAVEL_NAME ),
            'before_widget' => '<div id="%1$s" class="widget %2$s">',
            'after_widget'  => '</div>',
            'before_title'  => '<h2 class="widget-title">',
            'after_title'   => '</h2>',
        ));
    }
    public function func_ext_sendmail(){
        include_once('views/ext_travel_booking_form.php');
    }
}
new Ext_Travel_Booking_Form();