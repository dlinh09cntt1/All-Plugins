<div id="ext_travel_search_form" class="ext_travel_search_form">
    <form name="travel_forms" id="travel_form_s" method="post">
        <div class="ext_form_wrap">
            <div class="ext_form_item">
                <label for="travel_keyword">DESTINATION</label>
                <input type="text" name="travel_keyword" id="travel_keyword" placeholder="City, region or keywords">
            </div>
            <div class="ext_form_item">
                <label for="ext_time_start">Start date</label>
                <input type="date" name="ext_time_start" id="ext_time_start" placeholder="Departure">
            </div>
            <div class="ext_form_item">
                <label for="ext_time_end">End date</label>
                <input type="date" name="ext_time_end" id="ext_time_end" placeholder="Arrival">
            </div>
            <div class="ext_form_item">
                <label for="ext_budget">Max Budgets</label>
                <input id="ext_budget" name="ext_budget" type="text" placeholder="USD EX. 100">
            </div>
            <div class="ext_form_item">
                <input id="ext_search_btn" type="submit" value="Search">
            </div>
        </div>
    </form>
</div>