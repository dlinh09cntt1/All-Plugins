<?php get_header();?>
<?php
$show_search = get_option('ext_travel_archive_search');?>
<div class="archive-ext-travel">
    <?php 
        jal_install();
        $show_search = get_option('ext_travel_archive_search');
        $posts_per_page = get_option('ext_archive_per_page');
        $paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;
        $post_type = 'exactly_travel';
        $args_post = array(
            'post_type' => $post_type,
            'posts_per_page' => $posts_per_page,
            'paged' => $paged,
            'post_status' => 'publish'
        );
        $wp_query = new WP_Query($args_post);
        $total_records = $wp_query->found_posts;
        $total_pages = ceil($total_records/$posts_per_page);
        $attrs = array(
            'posts' => json_encode($wp_query->query_vars),
            'current_pages' => get_query_var( 'paged' ) ? get_query_var('paged') : 1,
            'max_pages' => $total_pages
        );
        if($show_search):?>
            <div class="archive-travel-search" data-attrs='<?php echo json_encode($attrs);?>'>
                <?php include_once('ext_travel_form_fe.php');?>
            </div>
        <?php endif;?>
        <div class="archive-travel-content" data-post_type="<?php echo esc_attr($post_type);?>" data-posts_per-page="<?php echo esc_attr($posts_per_page);?>" data-page="<?php echo esc_attr($paged);?>">
            <?php exactly_travel_query_post($post_type, $posts_per_page, $paged);?>
        </div>
</div>
<?php get_footer();?>