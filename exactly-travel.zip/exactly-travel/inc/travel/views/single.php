<?php get_header();?>
<div class="ext_travel_single">
    <?php 
        global $post;
        while ( have_posts()) : the_post();
        $ext_start_time = get_post_meta($post->ID,'ext-start-time',true);
        $newstart = date("d M", strtotime($ext_start_time));
        $ext_end_time = get_post_meta($post->ID,'ext-end-time',true);
        $newend = date("d M", strtotime($ext_end_time));
        $durationday = (strtotime($ext_end_time) - strtotime($ext_start_time));
        $ext_main_price = get_post_meta($post->ID,'ext-travel-main-price',true);
        $ext_sale_price = get_post_meta($post->ID,'ext-travel-discount-price',true);
        $ext_price = ($ext_sale_price) ? $ext_sale_price : $ext_main_price;
        ?>
        <article id="post-<?php the_ID(); ?>" <?php post_class( 'blog-post blog-single' ); ?>>
            <div class="travel_top">
                <ul>
                    <li>
                        <p class="ext_meta_title"><?php echo esc_html("Date", EXTTRAVEL_NAME);?></p>
                        <div class="ext_meta_content">
                            <span class="ext_start"><?php echo esc_attr($newstart);?></span> - <span class="ext_end"><?php echo esc_attr($newend);?></span>
                        </div>
                    </li>
                    <li>
                        <p class="ext_meta_title"><?php echo esc_html("Duration", EXTTRAVEL_NAME);?></p>
                        <div class="ext_meta_content">
                            <strong><?php echo (round($durationday / (60 * 60 * 24)) + 1);?><b class="extday"><?php echo esc_html("DAYS", EXTTRAVEL_NAME);?></b></strong>
                        </div>
                    </li>
                    <li>
                        <p class="ext_meta_title"><?php echo esc_html("Price", EXTTRAVEL_NAME);?></p>
                        <div class="ext_meta_content">
                            <strong><b class="type_cu">$</b><?php echo esc_attr($ext_price);?></strong>
                        </div>
                    </li>
                    <li>
                        <a href="#" class="ext_bk" data-ext_title="<?php the_title();?>" data-ext_url="<?php the_permalink();?>"><?php echo esc_html("Booking now", EXTTRAVEL_NAME);?></a>
                        <div class="ext_get_booking">
                            <div class="booking_wrap">
                                <span class="ext_close"><?php echo esc_html("X", EXTTRAVEL_NAME);?></span>
                                <div class="ext_post_booking">
                                    <h2 class="ext_title_booking"><strong><?php echo esc_html("BOOKING FOR ");?></strong><?php the_title();?></h2>
                                    <?php require_once EXTTRAVEL_DIR . 'inc/booking/views/ext_travel_booking_form.php';?>
                                </div>
                            </div>
                        </div>
                    </li>
                </ul>
            </div>
            <div class="travel_middle">
                <?php
                $ids = get_post_meta($post->ID, 'ext_travel_gallery_id', true);
                if($ids){?>
                <div class="ext-navi">
                    <a class="ext_previous">PREV</a>
                    <a class="ext_next">NEXT</a>
                </div>
                <div class="ext-image-container">
                    <?php foreach($ids as $imgs){?>
                        <div class="ext-slide"><?php echo wp_get_attachment_image($imgs, 'full');?></div>
                    <?php }?>
                </div>
                <?php }?>
                <h2 class="ext_single_title"><?php the_title();?></h2>
                <?php the_content();?>
            </div>
            <div class="travel_bottom">
                <h2 class="ext_title_program">TOUR PROGRAM</h2>
                <h6 class="ext_sub_program">EXPERIENCE WORLD CLASS 5 STARS HOTELS</h6>
                <?php
                $single_repeter_group = get_post_meta($post->ID, 'single_repeter_group', true);
                if(!empty($single_repeter_group)) {?>
                    <div class="ext_program_tours">
                        <?php foreach($single_repeter_group as $progarm){?>
                            <div class="ext_schedule">
                                <p class="ext_day"><?php echo esc_attr($progarm['title']);?></p>
                                <h4 class="ext_program_title"><?php echo esc_attr($progarm['tdesc']);?></h4>
                                <p class="ext_program_content"><?php echo esc_attr($progarm['tcontent']);?></p>
                            </div>
                        <?php }?>
                    </div>
                <?php }?>
            </div>
        </article>
    <?php endwhile;?>
</div>
<?php get_footer();?>