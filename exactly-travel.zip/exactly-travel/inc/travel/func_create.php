<?php
defined( 'ABSPATH' ) || exit;
class Ext_Travel_Post_Type{
	function __construct(){
		add_action('init',array(__CLASS__,'ext_travel_type_init'));
        add_filter( 'archive_template', array( $this, 'ext_travel_archive_page' ));
		add_filter( 'single_template', array( $this, 'ext_travel_single_page' ));
	}
	public static function ext_travel_type_init(){
		register_post_type( 'exactly_travel',
			array(
				'public'             => true,
				'publicly_queryable' => true,
				'show_ui'            => true,
				'show_in_menu'       => true,
				'show_in_nav_menus'  => true,
				'query_var'          => true,
				'rewrite'            => array( 'slug' => 'exactly_travel' ),
				'capability_type'    => 'post',
				'has_archive'        => true,
				'hierarchical'       => false,
				'menu_position'      => 4,
				'menu_icon'          => 'dashicons-admin-home',
				'supports'           => array('title', 'editor', 'thumbnail','comments'),
				'labels'             => array(
					'name'               => _x( 'Exactly Travel', EXTTRAVEL_NAME ),
					'singular_name'      => _x( 'Exactly Travel', EXTTRAVEL_NAME ),
					'menu_name'          => _x( 'Exactly Travel', EXTTRAVEL_NAME ),
					'name_admin_bar'     => _x( 'Exactly Travel', EXTTRAVEL_NAME ),
					'add_new'            => _x( 'add New Exactly Travel', EXTTRAVEL_NAME ),
					'add_new_item'       => __( 'Add New Exactly Travel', EXTTRAVEL_NAME ),
					'new_item'           => __( 'New Exactly Travel', EXTTRAVEL_NAME ),
					'edit_item'          => __( 'Edit Exactly Travel', EXTTRAVEL_NAME ),
					'view_item'          => __( 'View Exactly Travel', EXTTRAVEL_NAME ),
					'all_items'          => __( 'All Exactly Travel', EXTTRAVEL_NAME ),
					'search_items'       => __( 'Search Exactly Travel', EXTTRAVEL_NAME ),
					'parent_item_colon'  => __( 'Parent Exactly Travel:', EXTTRAVEL_NAME ),
					'not_found'          => __( 'No Exactly Travel found.', EXTTRAVEL_NAME ),
					'not_found_in_trash' => __( 'No Exactly Travel found in Trash.', EXTTRAVEL_NAME )
				),
			)
		);
		// Register event category
		register_taxonomy('exactly_travel_cat',
			array('exactly_travel'),
			array(
				'hierarchical'      => true,
				'show_ui'           => true,
				'show_admin_column' => true,
				'query_var'         => true,
				'rewrite'           => array( 'slug' => 'exactly_travel_cat' ),
				'labels'            => array(
					'name'              => _x( 'Categories', EXTTRAVEL_NAME ),
					'singular_name'     => _x( 'Category', EXTTRAVEL_NAME ),
					'search_items'      => __( 'Search Categories', EXTTRAVEL_NAME ),
					'all_items'         => __( 'All Categories', EXTTRAVEL_NAME ),
					'parent_item'       => __( 'Parent Category', EXTTRAVEL_NAME ),
					'parent_item_colon' => __( 'Parent Category:', EXTTRAVEL_NAME ),
					'edit_item'         => __( 'Edit Category', EXTTRAVEL_NAME ),
					'update_item'       => __( 'Update Category', EXTTRAVEL_NAME ),
					'add_new_item'      => __( 'Add New Category', EXTTRAVEL_NAME ),
					'new_item_name'     => __( 'New Category Name', EXTTRAVEL_NAME ),
					'menu_name'         => __( 'Category', EXTTRAVEL_NAME ),
				),
			)
		);
        // Register activity
        register_taxonomy('exactly_travel_activity',
            array('exactly_travel'),
            array(
                'hierarchical'      => true,
                'show_ui'           => true,
                'show_admin_column' => true,
                'query_var'         => true,
                'rewrite'           => array( 'slug' => 'exactly_travel_activity' ),
                'labels'            => array(
                    'name'              => _x( 'Travel Activity', EXTTRAVEL_NAME ),
                    'singular_name'     => _x( 'Activity', EXTTRAVEL_NAME ),
                    'search_items'      => __( 'Search Activity', EXTTRAVEL_NAME ),
                    'all_items'         => __( 'All Activity', EXTTRAVEL_NAME ),
                    'parent_item'       => null,
                    'parent_item_colon' => null,
                    'edit_item'         => __( 'Edit Activity', EXTTRAVEL_NAME ),
                    'update_item'       => __( 'Update Activity', EXTTRAVEL_NAME ),
                    'add_new_item'      => __( 'Add New Activity', EXTTRAVEL_NAME ),
                    'new_item_name'     => __( 'New Activity Name', EXTTRAVEL_NAME ),
                    'menu_name'         => __( 'Activity', EXTTRAVEL_NAME ),
                ),
            )
        );
        // Register Destination
        register_taxonomy('exactly_travel_destination',
            array('exactly_travel'),
            array(
                'hierarchical'      => true,
                'show_ui'           => true,
                'show_admin_column' => true,
                'query_var'         => true,
                'rewrite'           => array( 'slug' => 'exactly_travel_destination' ),
                'labels'            => array(
                    'name'              => _x( 'Travel Destination', EXTTRAVEL_NAME ),
                    'singular_name'     => _x( 'Destination', EXTTRAVEL_NAME ),
                    'search_items'      => __( 'Search Destination', EXTTRAVEL_NAME ),
                    'all_items'         => __( 'All Destination', EXTTRAVEL_NAME ),
                    'parent_item'       => null,
                    'parent_item_colon' => null,
                    'edit_item'         => __( 'Edit Destination', EXTTRAVEL_NAME ),
                    'update_item'       => __( 'Update Destination', EXTTRAVEL_NAME ),
                    'add_new_item'      => __( 'Add New Destination', EXTTRAVEL_NAME ),
                    'new_item_name'     => __( 'New Destination Name', EXTTRAVEL_NAME ),
                    'menu_name'         => __( 'Destination', EXTTRAVEL_NAME ),
                ),
            )
        );
        // Register Duration
        register_taxonomy('exactly_travel_duration',
            array('exactly_travel'),
            array(
                'hierarchical'      => true,
                'show_ui'           => true,
                'show_admin_column' => true,
                'query_var'         => true,
                'rewrite'           => array( 'slug' => 'exactly_travel_duration' ),
                'labels'            => array(
                    'name'              => _x( 'Travel Duration', EXTTRAVEL_NAME ),
                    'singular_name'     => _x( 'Duration', EXTTRAVEL_NAME ),
                    'search_items'      => __( 'Search Duration', EXTTRAVEL_NAME ),
                    'all_items'         => __( 'All Duration', EXTTRAVEL_NAME ),
                    'parent_item'       => null,
                    'parent_item_colon' => null,
                    'edit_item'         => __( 'Edit Duration', EXTTRAVEL_NAME ),
                    'update_item'       => __( 'Update Duration', EXTTRAVEL_NAME ),
                    'add_new_item'      => __( 'Add New Duration', EXTTRAVEL_NAME ),
                    'new_item_name'     => __( 'New Duration Name', EXTTRAVEL_NAME ),
                    'menu_name'         => __( 'Duration', EXTTRAVEL_NAME ),
                ),
            )
        );
        // Register Ranger Price
        register_taxonomy('exactly_travel_price',
            array('exactly_travel'),
            array(
                'hierarchical'      => true,
                'show_ui'           => true,
                'show_admin_column' => true,
                'query_var'         => true,
                'rewrite'           => array( 'slug' => 'exactly_travel_price' ),
                'labels'            => array(
                    'name'              => _x( 'Travel Ranger Price', EXTTRAVEL_NAME ),
                    'singular_name'     => _x( 'Ranger Price', EXTTRAVEL_NAME ),
                    'search_items'      => __( 'Search Ranger Price', EXTTRAVEL_NAME ),
                    'all_items'         => __( 'All Ranger Price', EXTTRAVEL_NAME ),
                    'parent_item'       => null,
                    'parent_item_colon' => null,
                    'edit_item'         => __( 'Edit Ranger Price', EXTTRAVEL_NAME ),
                    'update_item'       => __( 'Update Ranger Price', EXTTRAVEL_NAME ),
                    'add_new_item'      => __( 'Add New Price', EXTTRAVEL_NAME ),
                    'new_item_name'     => __( 'New Price Name', EXTTRAVEL_NAME ),
                    'menu_name'         => __( 'Ranger Price', EXTTRAVEL_NAME ),
                ),
            )
        );
		// Register event tag
		register_taxonomy('exactly_travel_tag',
			'casino',
			array(
				'hierarchical'          => false,
				'show_ui'               => true,
				'show_admin_column'     => true,
				'update_count_callback' => '_update_post_term_count',
				'query_var'             => true,
				'rewrite'               => array( 'slug' => 'exactly_travel_tag' ),
				'labels'                => array(
					'name'                       => _x( 'Tags', EXTTRAVEL_NAME ),
					'singular_name'              => _x( 'Tag', EXTTRAVEL_NAME ),
					'search_items'               => __( 'Search Tags', EXTTRAVEL_NAME ),
					'popular_items'              => __( 'Popular Tags', EXTTRAVEL_NAME ),
					'all_items'                  => __( 'All Tags', EXTTRAVEL_NAME ),
					'parent_item'                => null,
					'parent_item_colon'          => null,
					'edit_item'                  => __( 'Edit Tag', EXTTRAVEL_NAME ),
					'update_item'                => __( 'Update Tag', EXTTRAVEL_NAME ),
					'add_new_item'               => __( 'Add New Tag', EXTTRAVEL_NAME ),
					'new_item_name'              => __( 'New Tag Name', EXTTRAVEL_NAME ),
					'separate_items_with_commas' => __( 'Separate writers with commas', EXTTRAVEL_NAME ),
					'add_or_remove_items'        => __( 'Add or remove writers', EXTTRAVEL_NAME ),
					'choose_from_most_used'      => __( 'Choose from the most used writers', EXTTRAVEL_NAME ),
					'not_found'                  => __( 'No writers found.', EXTTRAVEL_NAME ),
					'menu_name'                  => __( 'Tag', EXTTRAVEL_NAME ),
				),
			)
		);
	}
    public function ext_travel_archive_page( $template ){
        global $post;
        if($post->post_type =='exactly_travel'){
            $template = EXTTRAVEL_DIR . '/inc/travel/views/archive.php';
        }
        return $template;
    }
    public function ext_travel_single_page( $template ){
        global $post;
        if($post->post_type == 'exactly_travel'){
            $template = EXTTRAVEL_DIR . 'inc/travel/views/single.php';
        }
        return $template;
    }
}
$ext_travel_post_type = new Ext_Travel_Post_Type();