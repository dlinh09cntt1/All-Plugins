<div class="user_logged_post">
    <div class="menu_left">
        <h2>Post Follow</h2>
        <div class="info_user">
            <?php 
                $user_ID = get_current_user_id();
                $current_user = wp_get_current_user();
            ?>
            <ul>
                <li>ID : <?php echo esc_attr($user_ID);?></li>
                <li>Username : <?php echo esc_html($current_user->user_login);?></li>
                <li>User email : <?php echo esc_html($current_user->user_email);?></li>
                <li>User first name : <?php echo esc_html($current_user->user_firstname);?></li>
                <li>User last name : <?php echo esc_html($current_user->user_lastname);?></li>
                <li>User display name : <?php echo esc_html( $current_user->display_name );?></li>
            </ul>
        </div>
    </div>
    <div class="list_follow_post">
        <h2>List post liked</h2>
        <div class="list_post">
            <?php
            $args_post = array(
                'post_type' => 'exactly_travel',
                'posts_per_page' => -1,
                'post_status' => 'publish'
            );
            $wp_query = new WP_Query($args_post);
            while ( $wp_query->have_posts() ) : $wp_query->the_post();
                if(initCheckInArray(intval(get_the_ID()))):?>
                    <article id="post-<?php the_ID(); ?>" <?php post_class( 'ext-travel-post' ); ?>>
                        <div class="ext_travel_thumbnails" data-ids="<?php the_ID();?>">
                            <?php if ( has_post_thumbnail() ) : ?>
                            <div class="ext-travel-thumbnails">
                                <a href="<?php esc_url( the_permalink() ); ?>" aria-hidden="true">
                                    <?php the_post_thumbnail('travel-blog', array( 'alt' => get_the_title() ) ); ?>
                                </a>
                            </div>
                            <?php endif;?>
                        </div>
                        <div class="ext_travel_content">
                            <h2 class="travel_title"><a href="<?php the_permalink();?>"><?php the_title();?></a></h2>
                        </div>
                    </article>
                <?php endif;?>
            <?php endwhile;?>
        </div>
    </div>
</div>