<?php
class Ext_Travel_Action{
    public function __construct(){
        
    }
}
new Ext_Travel_Action();