<?php
class Ext_Travel_Action_Func{
    public function __construct(){
        
    }
    public function ext_travel_form(){
        
    }
    public function ext_travel_ajax_search(){

    }
}