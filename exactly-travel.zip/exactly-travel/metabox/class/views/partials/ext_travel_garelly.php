<?php
/**
 * @package Travel Meta
 * @subpackage class/views/partials
 */
?>
<div class="inside">
    <div class="ext_travel_images_list">
        <div class="wrap">
            <a class="gallery-add button" href="#" data-uploader-title="Add new images" data-uploader-button-text="Add new images">Add more images</a>
            <ul id="gallery-metabox-list">
                <?php if ($this->initIdsGarelly()) : foreach ($this->initIdsGarelly() as $key => $value) : $image = wp_get_attachment_image_src($value); ?>
                <li>
                    <input type="hidden" name="ext_travel_gallery_id[<?php echo $key; ?>]" value="<?php echo $value; ?>">
                    <img class="image-preview" src="<?php echo $image[0]; ?>">
                    <a class="change-image button button-small" href="#" data-uploader-title="Change image" data-uploader-button-text="Change image">Change image</a><br>
                    <small class="ext_rm_img"><a class="remove-image" href="#">X</a></small>
                </li>
                <?php endforeach; endif; ?>
            </ul>
        </div>
    </div>
</div>