<?php
/**
 * @package Travel Meta
 * @subpackage class/views/partials
 */
?>
<div class="inside hidden">
    <table id="repeatable-fieldset-one" width="100%">
		<tbody>
			<?php
			if ( $this->initGroupField() ) :
				foreach ( $this->initGroupField() as $field ) {
					?>
					<tr>
						<td><input type="text"  style="width:98%;" name="title[]" value="<?php if($field['title'] != '') echo esc_attr( $field['title'] ); ?>" placeholder="Program day" /></td>
						<td><input type="text"  style="width:98%;" name="tdesc[]" value="<?php if ($field['tdesc'] != '') echo esc_attr( $field['tdesc'] ); ?>" placeholder="Title program day" /></td>
						<td><textarea rows="2" cols="50" style="width:98%;" name="tcontent[]"><?php if ($field['tcontent'] != '') echo esc_attr( $field['tcontent'] ); ?></textarea></td>
						<td><a class="button remove-row" href="#1">Remove</a></td>
					</tr>
					<?php
				}
			else :
				?>
				<tr>
					<td><input type="text"   style="width:98%;" name="title[]" placeholder="Program day"/></td>
					<td><input type="text"  style="width:98%;" name="tdesc[]" value="" placeholder="Title program day" /></td>
					<td><textarea rows="2" cols="50"  style="width:98%;" name="tcontent[]"></textarea></td>
					<td><a class="button  cmb-remove-row-button button-disabled" href="#">Remove</a></td>
				</tr>
			<?php endif; ?>
			<tr class="empty-row custom-repeter-text" style="display: none">
				<td><input type="text" style="width:98%;" name="title[]" placeholder="Program day"/></td>
				<td><input type="text" style="width:98%;" name="tdesc[]" value="" placeholder="Title program day"/></td>
				<td><textarea rows="2" cols="50" style="width:98%;" name="tcontent[]"></textarea></td>
				<td><a class="button remove-row" href="#">Remove</a></td>
			</tr>
			
		</tbody>
	</table>
	<p><a id="add-row" class="button" href="#">Add another</a></p>
</div>