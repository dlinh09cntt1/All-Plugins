<?php
/**
 * @package Travel Meta
 * @subpackage class/views/partials
 */
?>
<?php 
    $pro_arr = array();
    $pro_arr = $this->initPublic();
?>
<div class="inside hidden">
    <table id="ext-travel-time-booking" width="100%">
        <tbody>
            <tr>
                <td style="width:20%">Start time:</td>
                <td style="width:80%"><input type="date" id="ext-start-time" name="ext-start-time" value="<?php echo esc_attr($pro_arr[0]);?>" /></td>
            </tr>
            <tr>
                <td style="width:20%">End time:</td>
                <td style="width:80%"><input type="date" id="ext-end-time" name="ext-end-time" value="<?php echo esc_attr($pro_arr[1]);?>" /></td>
            </tr>
            <tr>
                <td style="width:20%">Tour price:</td>
                <td style="width:80%"><input type="number" id="ext-travel-main-price" name="ext-travel-main-price" min="0" class="currency" value="<?php echo esc_attr($pro_arr[2]);?>" /></td>
            </tr>
            <tr>
                <td style="width:20%">Discount price:</td>
                <td style="width:80%"><input type="number" id="ext-travel-discount-price" name="ext-travel-discount-price" min="0" class="currency" value="<?php echo esc_attr($pro_arr[3]);?>" /></td>
            </tr>
        </tbody>
    </table>
</div>