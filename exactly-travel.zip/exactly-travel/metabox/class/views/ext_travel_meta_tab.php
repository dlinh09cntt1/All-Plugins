<div id="authors-commentary-navigation">
    <h2 class="nav-tab-wrapper current">
        <a class="nav-tab nav-tab-active" href="javascript:;">Garelly</a>
        <a class="nav-tab" href="javascript:;">Tour Program</a>
        <a class="nav-tab" href="javascript:;">Properties</a>
    </h2>
    <?php
        include_once('partials/ext_travel_garelly.php');
        include_once('partials/ext_travel_properties.php');
        include_once('partials/ext_travel_public.php');
        // xác minh người dùng có khả năng xuất bản, lưu dữ liệu meta
        // Add a nonce field for security
        wp_nonce_field( 'ext_travel_repeterBox', 'ext_travel_formType' );
    ?>
</div>
