<?php
class Ext_Travel_Meta_Box{
	public function __construct(){
		add_action('add_meta_boxes', array($this, 'ext_travel_add_meta_box'));
		add_action( 'save_post', array( $this, 'save_post' ) ); 
	}
	public function ext_travel_add_meta_box(){
		add_meta_box(
			'exactly-travel-meta',
			'Exactly Travel',
			array($this, 'ext_travel_display_meta_box'),
			'exactly_travel',
			'normal',
			'default'
		);
	}
	public function ext_travel_display_meta_box(){
		include_once('views/ext_travel_meta_tab.php');
	}
	private function value_exists( $key ) {
		return ! empty( $_POST[ $key ] );
	}
	private function initGroupField(){
		global $post;
		$single_repeter_group = get_post_meta($post->ID, 'single_repeter_group', true);
		return $single_repeter_group;
	}
	private function initPublic(){
		global $post;
		$ext_start_time = get_post_meta($post->ID, 'ext-start-time', true);
		$ext_end_time = get_post_meta($post->ID, 'ext-end-time', true);
		$ext_main_price = get_post_meta($post->ID, 'ext-travel-main-price', true);
		$ext_discount_price = get_post_meta($post->ID, 'ext-travel-discount-price', true);
		$ext_properties = array($ext_start_time, $ext_end_time, $ext_main_price, $ext_discount_price);
		return $ext_properties;
	}
	private function is_valid_post_type() {
		return ! empty( $_POST['post_type'] ) && 'post' == $_POST['post_type'];
	}
	private function user_can_save( $post_id, $nonce_action, $nonce_id ) {
		$is_autosave = wp_is_post_autosave( $post_id );
		$is_revision = wp_is_post_revision( $post_id );
		$is_valid_nonce = ( isset( $_POST[ $nonce_action ] ) && wp_verify_nonce( $_POST[ $nonce_action ], $nonce_id ) );
		// Return true if the user is able to save; otherwise, false.
		return ! ( $is_autosave || $is_revision ) && $this->is_valid_post_type() && $is_valid_nonce;
	}
	private function delete_post_meta( $post_id, $meta_key ) {
		if ( '' !== get_post_meta( $post_id, $meta_key, true ) ) {
			delete_post_meta( $post_id, '$meta_key' );
		}
	}
	private function sanitize_data( $key, $is_array = false ) {
		$sanitized_data = null;
		if ( $is_array ) {
			$resources = $_POST[ $key ];
			$sanitized_data = array();
			foreach ( $resources as $resource ) {
				$resource = esc_url( strip_tags( $resource ) );
				if ( ! empty( $resource ) ) {
					$sanitized_data[] = $resource;
				}
			}
		} else {
			$sanitized_data = '';
			$sanitized_data = trim( $_POST[ $key ] );
			$sanitized_data = esc_textarea( strip_tags( $sanitized_data ) );
		}
		return $sanitized_data;
	}
	private function update_post_meta( $post_id, $meta_key, $meta_value ) {
		if ( is_array( $_POST[ $meta_key ] ) ) {
			$meta_value = array_filter( $_POST[ $meta_key ] );
		}
		update_post_meta( $post_id, $meta_key, $meta_value );
	}
	private function load_post_comments(){
		$args = array(
			'post_id' => get_the_ID(),
			'status'  => 'approve'
		);
		$comments = get_comments( $args );
		return $comments;
	}
	private function initIdsGarelly(){
		global $post;
		$ids = get_post_meta($post->ID, 'ext_travel_gallery_id', true);
		return $ids;
	}
	public function save_post($post_id){
		if (!isset($_POST['ext_travel_formType']) && !wp_verify_nonce($_POST['ext_travel_formType'], 'ext_travel_repeterBox'))
		return;
		if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)
			return;
		if (!current_user_can('edit_post', $post_id))
			return;
		// Garelly
		if(isset($_POST['ext_travel_gallery_id'])) {
			update_post_meta($post_id, 'ext_travel_gallery_id', $_POST['ext_travel_gallery_id']);
		}else{
			delete_post_meta($post_id, 'ext_travel_gallery_id');
		}
		// Repeater
		$old = get_post_meta($post_id, 'single_repeter_group', true);
		$new = array();
		$titles = $_POST['title'];
		$tdescs = $_POST['tdesc'];
		$tcontent = $_POST['tcontent'];
		$count = count( $titles );
		for ( $i = 0; $i < $count; $i++ ) {
			if ( $titles[$i] != '' ) {
				$new[$i]['title'] = stripslashes( strip_tags( $titles[$i] ) );
				$new[$i]['tdesc'] = stripslashes( $tdescs[$i] );
				$new[$i]['tcontent'] = stripslashes( $tcontent[$i] );
			}
		}
		if ( !empty( $new ) && $new != $old ){
			update_post_meta( $post_id, 'single_repeter_group', $new );
		} elseif ( empty($new) && $old ) {
			delete_post_meta( $post_id, 'single_repeter_group', $old );
		}
		$repeter_status= $_REQUEST['repeter_status'];
		update_post_meta( $post_id, 'repeter_status', $repeter_status );
		// End Repeater
		// Properties
		if(isset($_POST['ext-start-time'])) {
			update_post_meta($post_id, 'ext-start-time', $_POST['ext-start-time']);
		}else{
			delete_post_meta($post_id, 'ext-start-time');
		}
		if(isset($_POST['ext-end-time'])) {
			update_post_meta($post_id, 'ext-end-time', $_POST['ext-end-time']);
		}else{
			delete_post_meta($post_id, 'ext-end-time');
		}
		if(isset($_POST['ext-travel-main-price'])) {
			update_post_meta($post_id, 'ext-travel-main-price', $_POST['ext-travel-main-price']);
		}else{
			delete_post_meta($post_id, 'ext-travel-main-price');
		}
		if(isset($_POST['ext-travel-discount-price'])) {
			update_post_meta($post_id, 'ext-travel-discount-price', $_POST['ext-travel-discount-price']);
		}else{
			delete_post_meta($post_id, 'ext-travel-discount-price');
		}
		// End properties
	}
}