<?php
include_once('class/ext_travel_class_meta.php');
class Ext_Travel_Meta_Init{
	private $ext_meta_box;
	public function __construct(){
		$this->ext_meta_box = new Ext_Travel_Meta_Box();
	}
}
new Ext_Travel_Meta_Init();