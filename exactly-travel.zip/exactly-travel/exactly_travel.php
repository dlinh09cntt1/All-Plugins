<?php
/**
 * Plugin name: Exactly travel
 * Description: Booking Tour, Search Hotel, Review Tour
 * Author: Linh D. Tran
 * Version: 1.0.0
 * License: GPLv2 or later
 */

 define('EXTTRAVEL_NAME', 'exttravel');
 define('EXTTRAVEL_DIR', plugin_dir_path(__FILE__));
 define('EXTTRAVEL_URL', plugin_dir_url(__FILE__));
// include
require_once EXTTRAVEL_DIR . '/inc/travel/func_create.php';
require_once EXTTRAVEL_DIR . 'inc/wp_admin_setting.php';
require_once EXTTRAVEL_DIR . 'metabox/metabox_init.php';
require_once EXTTRAVEL_DIR . 'inc/booking/ext_travel_booking.php';
require_once EXTTRAVEL_DIR . 'inc/functions.php';

 if(!class_exists('Ext_Travel_Post')){
    class Ext_Travel_Post{
        function __construct(){
            // init function
            add_action('admin_enqueue_scripts', array($this, 'func_ext_travel_post'));
            add_action('wp_enqueue_scripts', array($this, 'ext_travel_frontend_scripts'));
        }
        function func_ext_travel_post(){
            // enqueue script, enqueue css
            wp_enqueue_style( 'ext-travel-style', plugins_url('assets/css/ext_travel_style.css', __FILE__), array());
            wp_enqueue_script( 'ext-travel-admin', plugins_url('assets/js/ext_travel_main.js', __FILE__), array('jquery'), '1.0', true );
        }
        function ext_travel_frontend_scripts(){
            wp_enqueue_style('main-style', plugins_url('assets/css/main_fe_style.css', __FILE__), array(), true);
            wp_enqueue_script( 'ext-travel-fe-script', plugins_url('assets/js/ext_travel_fe.js', __FILE__), array('jquery'), '1.0', true );
            $php_array = array(
                'admin_ajax' => admin_url( 'admin-ajax.php' )
            );
            wp_localize_script( 'ext-travel-fe-script', 'exactly_array_ajaxp', $php_array );
        }
    }
 }
 // create object
function func_ext_travel_object(){
    // new object
    $exttravel = new Ext_Travel_Post();
}
// run plugin
add_action('plugins_loaded', 'func_ext_travel_object');
