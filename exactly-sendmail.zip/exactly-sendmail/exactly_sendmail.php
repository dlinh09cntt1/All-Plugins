<?php
/**
 * Plugin Name: Exactly Send Mail
 * Description: Form send mail by ajax
 * Author: Linh D. Tran
 * Version: 1.0.0
 * License: GPLv2 or later
 */

// Define url
define('EXT_NAME', 'ext');
define('EXT_DIR', plugin_dir_path(__FILE__));
define('EXT_URL', plugin_dir_url(__FILE__));
// Include setting page and widget
require_once EXT_DIR . 'shortcodes/ext_shortcode.php';
require_once EXT_DIR . 'inc/functions.php';
require_once EXT_DIR . 'inc/wp_admin_setting.php';
// Create main class
if(!class_exists('Ext_Sendmail')){
    class Ext_Sendmail{
        function __construct(){
            add_action('init', array($this, 'func_ext_sendmail'));
        }
        function func_ext_sendmail(){
           add_action('wp_enqueue_scripts', array($this, 'ext_frontend_scripts'));
            require_once EXT_DIR . 'inc/mail_ajax.php';
        }
        function ext_frontend_scripts(){
            // Enqueue css
            wp_enqueue_style('main-style', plugins_url('assets/css/main_style.css', __FILE__), array(), true);
            wp_enqueue_script('exactly-main-script', plugins_url('assets/js/main_script.js', __FILE__), array('jquery'), '1.0.0', true);
            // url ajax
            $php_arrays = array(
                'admin_ajax' => admin_url('admin-ajax.php')
            );
            wp_localize_script('exactly-main-script', 'exactly_array_ajaxps', $php_arrays);
        }
    }
}
// create new object and run class Ext_Sendmail
function func_ext_sendmail_obj(){
    $ext_sendmail = new Ext_Sendmail();
}
// Add plugin loaded
add_action('plugins_loaded', 'func_ext_sendmail_obj');
