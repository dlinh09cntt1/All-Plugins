<?php
add_action('wp_ajax_ExactlySendMailUser', 'ExactlySendMailUser_init');
add_action('wp_ajax_nopriv_ExactlySendMailUser', 'ExactlySendMailUser_init');
function ExactlySendMailUser_init(){
    // Main Email
    $to = get_option('email_personnel');
    // Get value after client send
    $user_name = (!empty($_POST['ext_name'])) ? $_POST['ext_name'] : '';
    $user_email = (!empty($_POST['ext_email'])) ? $_POST['ext_email'] : '';
    $ext_subject = (!empty($_POST['ext_subject'])) ? $_POST['ext_subject'] : '';
    $ext_comment = (!empty($_POST['ext_comment'])) ? $_POST['ext_comment'] : '';
    $content = 'Username: '.$user_name.' Usermail: '.$user_email.' Comment: '.$ext_comment;
    $mailResult = false;
    $mailResult = wp_mail( $to, $ext_subject, $content);
    echo esc_attr($mailResult);
    die();
}