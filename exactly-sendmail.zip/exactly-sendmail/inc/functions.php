<?php
defined( 'ABSPATH' ) || exit;
// register widget
function ext_widgets_init(){
	register_sidebar( array(
        'name'          => esc_html__( 'Exactly mail sidebar', EXT_NAME ),
        'id'            => 'ext-sendmail-sidebar',
        'description'   => esc_html__( 'Add widgets here to appear in your sidebar Ext', EXT_NAME ),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h2 class="widget-title">',
        'after_title'   => '</h2>',
    ));
}
add_action( 'widgets_init', 'ext_widgets_init');