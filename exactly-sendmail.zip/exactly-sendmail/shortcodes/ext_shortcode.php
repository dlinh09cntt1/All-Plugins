<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
if(!function_exists('func_ext_sendmail')){
    function func_ext_sendmail($atts){
        $atts = shortcode_atts(array(
            'title' => ''
        ), $atts);
        extract($atts);
        ob_start();?>
        <div class="ext_form_mail">
            <h3 class="ext_title"><?php echo esc_html__($title);?></h3>
            <form id="ext_mail" class="ext_mail" method="post" action="">
                <input type="text" id="ext_username" name="ext_username" placeholder="Full name" />
                <input type="email" id="ext_email" name="ext_email" placeholder="Email" /><br />
                <input type="text" id="ext_subject" name="ext_subject" placeholder="Subject" /><br />
                <textarea name="ext_comment" id="ext_comment" placeholder="Your ideas" rows="4" cols="50"></textarea><br />
                <input type="submit" name="ext_submit" id="ext_submit" value="Submit message" />
                <label><span class="error_messager"></span></label>
            </form>
        </div>
        <?php 
        return ob_get_clean();
    }
}
add_shortcode('exactly_form_mail', 'func_ext_sendmail');
