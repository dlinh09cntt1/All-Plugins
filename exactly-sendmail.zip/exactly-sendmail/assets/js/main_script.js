;(function($){
    'use strict'
    
    var initSendMail = function(){
        var _mail = $('.ext_form_mail');
        _mail.on('click', '#ext_submit', function(e){
            e.preventDefault();
            var _this = $(this),
                ext_name = $('#ext_username').val(),
                ext_email = $('#ext_email').val(),
                ext_subject = $('#ext_subject').val(),
                ext_comment = $('#ext_comment').val();
            if(ext_name == '' || ext_email == ''){
                $('.error_messager').text('Vui lòng nhập user/email!');
                return;
            }
            $.ajax({
                cache: false,
                timeout: 8000,
                url: exactly_array_ajaxps.admin_ajax,
                type: 'POST',
                data: ({
                    action: 'ExactlySendMailUser',
                    ext_name: ext_name,
                    ext_email: ext_email,
                    ext_subject: ext_subject,
                    ext_comment: ext_comment
                }),
                beforeSend: function(xhr){
                   
                },
                success: function(data){
                    if(data == false){
                        $('.error_messager').text('Email has not been sent!');
                    }else{
                        $('.error_messager').text('Email sent successfully!');
                    }
                },
                error: function(error){
                    console.log('Error! ' + error);
                },
                complete: function(xhr){

                }
            })
        })
    }
    $(function(){
        initSendMail();
    });
})(jQuery);